<?php

namespace Firebear\ImportExport\Logger;

class Logger extends \Monolog\Logger
{

}
